Hi, I’m GoldenRat
I don't know how to code but love it
and I'm learning it
I don't know how GitHub will be useful
But I like it
